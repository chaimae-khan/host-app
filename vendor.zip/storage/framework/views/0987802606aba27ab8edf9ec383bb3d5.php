<!-- resources/views/layouts/partials/notifications.blade.php -->
<li class="dropdown notification-list topbar-dropdown">
    <a class="nav-link dropdown-toggle nav-link" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false" onclick="resetNotificationCount()">
        <i data-feather="bell" class="noti-icon"></i>
        <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
            <span class="badge bg-danger rounded-circle noti-icon-badge" id="notification-badge"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
        <?php endif; ?>
    </a>
    <div class="dropdown-menu dropdown-menu-end dropdown-lg">
        <!-- item-->
        <div class="dropdown-item noti-title">
            <h5 class="m-0">
                <span class="float-end">
                    <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
                        <form action="<?php echo e(route('notifications.markAllAsRead')); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-link btn-sm p-0 text-dark">
                                <small>Tout marquer comme lu</small>
                            </button>
                        </form>
                    <?php endif; ?>
                </span>Notifications
            </h5>
        </div>

        <div class="noti-scroll" data-simplebar>
            <?php $__empty_1 = true; $__currentLoopData = auth()->user()->notifications()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e($notification->data['view_url'] ?? '#'); ?>" class="dropdown-item notify-item">
                    <div class="notify-icon bg-primary">
                        <i class="mdi mdi-comment-account-outline"></i>
                    </div>
                    <p class="notify-details">
                        <?php echo e($notification->data['message']); ?>

                        <small class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></small>
                    </p>
                    
                    <div class="d-flex justify-content-end mt-1">
                        <?php if(!$notification->read_at): ?>
                            <form action="<?php echo e(route('notifications.markAsRead', $notification->id)); ?>" method="POST" class="ms-1">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-link text-primary p-0">
                                    <i class="mdi mdi-check-all"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <a href="javascript:void(0);" class="dropdown-item notify-item">
                    <p class="notify-details">
                        Aucune notification
                    </p>
                </a>
            <?php endif; ?>
        </div>
    </div>
</li>

<script>
function resetNotificationCount() {
    // Hide the notification badge
    const badge = document.getElementById('notification-badge');
    if (badge) {
        badge.style.display = 'none';
    }
    
    // Mark all as read in the backend
    fetch('<?php echo e(route('notifications.markAllAsRead')); ?>', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
        }
    }).catch(error => console.error('Error:', error));
}
</script><?php /**PATH /home/u815974231/domains/red-guanaco-935735.hostingersite.com/public_html/resources/views/layouts/partials/notifications.blade.php ENDPATH**/ ?>