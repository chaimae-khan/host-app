<?php $__env->startSection('dashboard'); ?>
<!-- detail of command page  -->
<div class="content-page">
    <div class="content">

        <!-- Début du contenu -->
        <div class="container-fluid ">
            <div class="card card-body py-3 mt-3">
                <div class="row align-items-center">
                    <div class="col-12">
                        <div class="d-sm-flex align-items-center justify-space-between">
                            <h4 class="mb-4 mb-sm-0 card-title">Gestion de Production</h4>
                            <nav aria-label="breadcrumb" class="ms-auto">
                                <ol class="breadcrumb">
                                   
                                    <li class="breadcrumb-item" aria-current="page">
                                        <span class="badge fw-medium fs-6 bg-primary-subtle text-primary">
                                            Détail commande
                                        </span>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        
            <div class="widget-content searchable-container list">
                <div class="card card-body">
                    <h5 class="card-title border p-2 bg-light rounded-2 mb-4">Information Demandeur par commande N° <?php echo e($bonVente->id); ?></h5>
                    <div class="row">
                        <div class="col-md-12 col-xl-6">
                            <div class="form-group">
                                <div class="mb-4">
                                    <label for="" style="min-width: 115px">Nom Demandeur :</label>
                                    <span class="border p-2 bg-light rounded-2"><?php echo e($Formateur->prenom); ?> <?php echo e($Formateur->nom); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-xl-6">
                            <div class="form-group">
                                <div class="mb-4">
                                    <label for="" style="min-width: 115px">Téléphone Demandeur :</label>
                                    <span class="border p-2 bg-light rounded-2"><?php echo e($Formateur->telephone ?? 'Non spécifié'); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Status History Section - ADD THIS AFTER THE "Information Demandeur" SECTION -->
            <?php if(isset($statusHistory) && count($statusHistory) > 0): ?>
            <div class="card card-body">
                <h5 class="card-title border p-2 bg-light rounded-2">
                    <i class="mdi mdi-history"></i> Historique des changements de statut
                </h5>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead class="table-light">
                            <tr>
                                <th width="30%">Statut</th>
                                <th width="40%">Date de changement</th>
                                <th width="30%">Modifié par</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $statusHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $change): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($change->status == 'Création'): ?>
                                        <span class="badge bg-info"><?php echo e($change->status); ?></span>
                                    <?php elseif($change->status == 'Validation'): ?>
                                        <span class="badge bg-success">Réception</span>
                                    <?php elseif($change->status == 'Refus'): ?>
                                        <span class="badge bg-danger"><?php echo e($change->status); ?></span>
                                    <?php elseif($change->status == 'Livraison'): ?>
                                        <span class="badge bg-primary"><?php echo e($change->status); ?></span>
                                    <?php elseif($change->status == 'Réception'): ?>
                                        <span class="badge bg-warning">Validation</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e($change->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <i class="mdi mdi-calendar-clock"></i>
                                    <?php echo e(\Carbon\Carbon::parse($change->date)->format('d/m/Y H:i:s')); ?>

                                </td>
                                <td>
                                    <i class="mdi mdi-account"></i>
                                    <?php echo e($change->user_name); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>
        
            <div class="card card-body">
                <h5 class="card-title border p-2 bg-light rounded-2">Fiche détail Commande</h5>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped TableLineOrder">
                        <thead>
                            <tr>
                                <th>Produit</th>
                                <th>Quantité</th>
                                <th>Quantité Transférée</th>
                                <th>Prix</th>
                                <th>Total</th>
                                <th>Détails Transferts</th>
                                <th>Détails Retours</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $SumTotal = 0;
                            ?>
                            <?php $__currentLoopData = $Data_Vente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $SumTotal += $value->total;
                                ?>
                                <tr>
                                    <td><?php echo e($value->name); ?></td>
                                    <td><?php echo e($value->qte); ?></td>
                                    <td>
                                        <?php if(isset($value->contente_transfert) && $value->contente_transfert > 0): ?>
                                            <span class="badge bg-info"><?php echo e($value->contente_transfert); ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">0</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end"><?php echo e(number_format($value->price_achat, 2, ',', ' ')); ?></td>
                                    <td class="text-end"><?php echo e(number_format($value->total, 2, ',', ' ')); ?></td>
                                    <td>
                                        <?php if(isset($transferDetails[$value->idproduit])): ?>
                                            <button class="btn btn-sm btn-info" 
                                                    type="button" 
                                                    data-bs-toggle="collapse" 
                                                    data-bs-target="#transferDetails<?php echo e($value->idproduit); ?>" 
                                                    aria-expanded="false">
                                                <i class="fa-solid fa-eye"></i> Voir
                                            </button>
                                            
                                            <div class="collapse mt-2" id="transferDetails<?php echo e($value->idproduit); ?>">
                                                <div class="card card-body">
                                                    <h6 class="card-subtitle mb-2 text-muted">Détails des transferts</h6>
                                                    <table class="table table-sm">
                                                        <thead>
                                                            <tr>
                                                                <th>Destinataire</th>
                                                                <th>Quantité</th>
                                                                <th>Date</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $transferDetails[$value->idproduit]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($transfer->recipient_name); ?></td>
                                                                <td><?php echo e($transfer->quantite); ?></td>
                                                                <td><?php echo e(date('d/m/Y H:i', strtotime($transfer->transfer_date))); ?></td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Aucun transfert</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if(isset($returnDetails[$value->idproduit])): ?>
                                            <button class="btn btn-sm btn-warning" 
                                                    type="button" 
                                                    data-bs-toggle="collapse" 
                                                    data-bs-target="#returnDetails<?php echo e($value->idproduit); ?>" 
                                                    aria-expanded="false">
                                                <i class="fa-solid fa-eye"></i> Voir
                                            </button>
                                            
                                            <div class="collapse mt-2" id="returnDetails<?php echo e($value->idproduit); ?>">
                                                <div class="card card-body">
                                                    <h6 class="card-subtitle mb-2 text-muted">Détails des retours</h6>
                                                    <table class="table table-sm">
                                                        <thead>
                                                            <tr>
                                                                <th>Demandeur</th>
                                                                <th>Quantité</th>
                                                                <th>Date</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $returnDetails[$value->idproduit]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($return->recipient_name); ?></td>
                                                                <td><?php echo e($return->quantite); ?></td>
                                                                <td><?php echo e(date('d/m/Y H:i', strtotime($return->return_date))); ?></td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Aucun retour</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="d-flex">
                        <div class="flex-fill"></div>
                        <div class="flex-fill">
                            <table class="table table-striped table-bordered">
                                <tbody>
                                    <tr>
                                        <th>Total HT</th>
                                        <th class="text-end"><?php echo e(number_format($SumTotal, 2, ',', ' ')); ?> DH</th>
                                    </tr>
                                    <tr>
                                        <th>Statut</th>
                                        <th class="text-end">
                                            <?php if($bonVente->status == 'Création'): ?>
                                                <span class="badge bg-info"><?php echo e($bonVente->status); ?></span>
                                            <?php elseif($bonVente->status == 'Validation'): ?>
                                                <span class="badge bg-success"><?php echo e($bonVente->status); ?></span>
                                            <?php elseif($bonVente->status == 'Refus'): ?>
                                                <span class="badge bg-danger"><?php echo e($bonVente->status); ?></span>
                                            <?php elseif($bonVente->status == 'Livraison'): ?>
                                                <span class="badge bg-primary"><?php echo e($bonVente->status); ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary"><?php echo e($bonVente->status); ?></span>
                                            <?php endif; ?>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th>Type Commande</th>
                                        <th class="text-end"><?php echo e($bonVente->type_commande ?? 'Alimentaire'); ?></th>
                                    </tr>
                                    
                                    <?php if($bonVente->type_commande === 'Alimentaire'): ?>
                                        <tr>
                                            <th>Type Menu</th>
                                            <th class="text-end">
                                                <?php
                                                    $menuType = $bonVente->type_menu ?? 'Menu eleves';
                                                    $displayMenuType = $menuType === 'Menu eleves' ? 'Menu standard' : $menuType;
                                                ?>
                                                <?php echo e($displayMenuType); ?>

                                            </th>
                                        </tr>
                                        
                                        <!-- Menu Composition Section -->
                                        <?php if($bonVente->entree || $bonVente->plat_principal || $bonVente->accompagnement || $bonVente->dessert): ?>
                                        <tr>
                                            <th colspan="2" class="text-center bg-info-subtle">
                                                <i class="mdi mdi-silverware-fork-knife"></i> Composition du Menu
                                            </th>
                                        </tr>
                                        
                                        <?php if($bonVente->entree): ?>
                                        <tr>
                                            <th><i class="mdi mdi-food-fork-drink"></i> Entrée</th>
                                            <th class="text-end"><?php echo e($bonVente->entree); ?></th>
                                        </tr>
                                        <?php endif; ?>
                                        
                                        <?php if($bonVente->plat_principal): ?>
                                        <tr>
                                            <th><i class="mdi mdi-food"></i> Plat Principal</th>
                                            <th class="text-end"><?php echo e($bonVente->plat_principal); ?></th>
                                        </tr>
                                        <?php endif; ?>
                                        
                                        <?php if($bonVente->accompagnement): ?>
                                        <tr>
                                            <th><i class="mdi mdi-bread-slice"></i> Accompagnement</th>
                                            <th class="text-end"><?php echo e($bonVente->accompagnement); ?></th>
                                        </tr>
                                        <?php endif; ?>
                                        
                                        <?php if($bonVente->dessert): ?>
                                        <tr>
                                            <th><i class="mdi mdi-cupcake"></i> Dessert</th>
                                            <th class="text-end"><?php echo e($bonVente->dessert); ?></th>
                                        </tr>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                        
                                        <!-- Quantity attributes section -->
                                        <tr>
                                            <th colspan="2" class="text-center bg-warning-subtle">
                                                <i class="mdi mdi-account-group"></i> Effectifs
                                            </th>
                                        </tr>
                                        <tr>
                                            <th>Nombre d'élèves</th>
                                            <th class="text-end"><?php echo e($bonVente->eleves ?? 0); ?></th>
                                        </tr>
                                        <tr>
                                            <th>Nombre de personnel</th>
                                            <th class="text-end"><?php echo e($bonVente->personnel ?? 0); ?></th>
                                        </tr>
                                        <tr>
                                            <th>Nombre d'invités</th>
                                            <th class="text-end"><?php echo e($bonVente->invites ?? 0); ?></th>
                                        </tr>
                                        <tr>
                                            <th>Nombre divers</th>
                                            <th class="text-end"><?php echo e($bonVente->divers ?? 0); ?></th>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-4">
                <a href="<?php echo e(url('FactureVente/' . app('Hashids\Hashids')->encode($bonVente->id))); ?>" 
                   class="btn btn-info" target="_blank">
                    <i class="fa-solid fa-print"></i> Imprimer Bon de Commande
                </a>
                <a href="<?php echo e(url('Command')); ?>" class="btn btn-secondary">
                    <i class="fa-solid fa-arrow-left"></i> Retour
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u815974231/domains/red-guanaco-935735.hostingersite.com/public_html/resources/views/vente/list.blade.php ENDPATH**/ ?>