<?php $__env->startSection('dashboard'); ?>
<div class="content-page">
    <div class="content">

        <!-- Début du contenu -->
        <div class="container-fluid ">
            <div class="card card-body py-3 mt-3">
                <div class="row align-items-center">
                    <div class="col-12">
                        <div class="d-sm-flex align-items-center justify-space-between">
                            <h4 class="mb-4 mb-sm-0 card-title">Gestion de Production</h4>
                            <nav aria-label="breadcrumb" class="ms-auto">
                                <ol class="breadcrumb">
                                   
                                    <li class="breadcrumb-item" aria-current="page">
                                        <span class="badge fw-medium fs-6 bg-primary-subtle text-primary">
                                            Détail achat
                                        </span>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        
            <div class="widget-content searchable-container list">
                <div class="card card-body">
                    <h5 class="card-title border p-2 bg-light rounded-2 mb-4">Information fournisseur par commande N° <?php echo e($bonReception->id); ?></h5>
                    <div class="row">
                        <div class="col-md-12 col-xl-6">
                            <div class="form-group">
                                <div class="mb-4">
                                    <label for="" style="min-width: 115px">Nom fournisseur :</label>
                                    <span class="border p-2 bg-light rounded-2"><?php echo e($Fournisseur->entreprise); ?></span>
                                </div>
                            </div>
                            
        
                        </div>
                        <div class="col-md-12 col-xl-6">
                            <div class="form-group">
                                <div class="mb-4">
                                    <label for="" style="min-width: 115px">Téléphone fournisseur :</label>
                                    <span class="border p-2 bg-light rounded-2"><?php echo e($Fournisseur->Telephone); ?></span>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        
            <div class="card card-body">
                <h5 class="card-title border p-2 bg-light rounded-2">Fiche détail achat </h5>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped TableLineOrder">
                        <thead>
                            <tr>
                                <th>Produit</th>
        
                                <th>Quantite</th>
        
                                <th>Prix</th>
        
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $SumTotal = 0;
                            ?>
                            <?php $__currentLoopData = $Data_Achat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $SumTotal +=$value->total;
                                ?>
                                <tr>
                                    <td><?php echo e($value->name); ?></td>
                                    <td><?php echo e($value->qte); ?></td>
                                    <td class="text-end"><?php echo e(number_format($value->price_achat, 2, ',', ' ')); ?></td>
                                    <td class="text-end"><?php echo e(number_format($value->total, 2, ',', ' ')); ?></td>

                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="d-flex">
                        <div class="flex-fill"></div>
                        <div class="flex-fill">
                            <table class="table table-striped table-bordered">
                                <tbody><tr>
                                    <th>Total HT</th>
                                    <th class="text-end"><?php echo e($SumTotal); ?> DH</th>
                                </tr>
                                
                            </tbody></table>
                        </div>
                    </div>
        
        
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u815974231/domains/red-guanaco-935735.hostingersite.com/public_html/resources/views/achat/list.blade.php ENDPATH**/ ?>