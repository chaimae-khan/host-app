<?php $__env->startSection('dashboard'); ?>

<!-- Scripts personnalisés -->
<script src="<?php echo e(asset('js/achat/script.js')); ?>"></script>
<script>

    var getSubcategories_url = "<?php echo e(url('getSubcategories')); ?>";
    var getRayons_url  = "<?php echo e(url('getRayons')); ?>";
    var csrf_token     = "<?php echo e(csrf_token()); ?>";
    var getProduct     = "<?php echo e(url('getProduct')); ?>";
    var PostInTmpAchat = "<?php echo e(url('PostInTmpAchat')); ?>";
    var GetTmpAchatByFournisseur = "<?php echo e(url('GetTmpAchatByFournisseur')); ?>";
    var GetAchatList   = "<?php echo e(url('getAchatList')); ?>"
    var StoreAchat     = "<?php echo e(url('StoreAchat')); ?>";
    var Achat          = "<?php echo e(url('Achat')); ?>";
    var UpdateQteTmp   = "<?php echo e(url('UpdateQteTmp')); ?>";
    var DeleteRowsTmpAchat = "<?php echo e(url('DeleteRowsTmpAchat')); ?>";
    var GetTotalTmpByForunisseurAndUser = "<?php echo e(url('GetTotalTmpByForunisseurAndUser')); ?>";
    var DeleteAchat    = "<?php echo e(url('DeleteAchat')); ?>";
    var EditAchat      = "<?php echo e(url('EditAchat')); ?>";
    var UpdateAchat    = "<?php echo e(url('UpdateAchat')); ?>";
    var GetCategorieByClass = "<?php echo e(url('GetCategorieByClass')); ?>";
    var UpdateStatusAchat    = "<?php echo e(url('UpdateStatusAchat')); ?>"; 
    var AddProduct = "<?php echo e(url('addProduct')); ?>";
    var ChangeStatusAchat = "<?php echo e(url('ChangeStatusAchat')); ?>";


</script>
<style>
    .table-responsive {
        overflow-x: hidden;
    }
    .TableProductAchat tbody tr:hover {
        cursor: pointer; 
    }
    .dataTables-custom-controls {
        margin-bottom: 15px;
    }
    .dataTables-custom-controls label {
        margin-bottom: 0;
    }
    .dataTables-custom-controls .form-control {
        display: inline-block;
        width: auto;
        vertical-align: middle;
    }
    .dataTables-custom-controls .form-select {
        display: inline-block;
        width: auto;
        vertical-align: middle;
    }
</style>

<div class="content-page"> 
    <div class="content">

        <!-- Début du contenu -->
        <div class="container-fluid">

            <div class="py-3 d-flex align-items-sm-center flex-sm-row flex-column">
                <div class="flex-grow-1">
                    <h4 class="fs-18 fw-semibold m-0">Liste des achats</h4>
                </div>
                
                <div class="text-end">
                    <ol class="breadcrumb m-0 py-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Applications</a></li>
                        <li class="breadcrumb-item active">Achat</li>
                    </ol>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">

                        <div class="card-body">
                            <div class="mb-3">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Achat-ajoute')): ?>
                                <button class="btn btn-primary" style="margin-right: 5px" data-bs-toggle="modal" data-bs-target="#ModalAddAchat">
                                    <i class="fa-solid fa-plus"></i> Ajouter un achat
                                </button>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Liste des achats -->
                            <div class="table-responsive">
                                <table class="table datatable TableAchat">
                                    <thead class="thead-light">
                                        <tr>
                                            <th scope="col">Fournisseur</th>
                                            <th scope="col">Total</th>
                                            <th scope="col">status</th>
                                            <th scope="col">Créé par</th>
                                            <th scope="col">Créé le</th>
                                            <th scope="col">Action</th>    
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!-- Les données seront chargées par DataTables -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Ajouter un Achat -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Achat-ajoute')): ?>
        <div class="modal fade" id="ModalAddAchat" tabindex="-1" aria-labelledby="ModalAddAchat" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalAddLocalLabel">Ajouter un nouvel achat</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                           <div class="col-sm-12 col-md-12 col-xl-6">
                                <div class="card bg-light shadow">
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="" class="label-form">Fournisseur</label>
                                            <select name="fournisseur" class="form-select" id="DropDown_fournisseur">
                                                <option value="0">Veuillez sélectionner un fournisseur</option>
                                                <?php $__currentLoopData = $Fournisseur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->entreprise); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group mt-2">
                                            <div class="row">
                                                <div class="col-6">
                                                    <label for="" class="form-label">Produit</label>
                                                </div>
                                                <div class="col-6 text-end">
                                                    <a href="#" class="text-danger linkCallModalAddProduct">Ajouter Produit</a>
                                                </div>
                                            </div>
                                            <input type="text" class="form-control input_products" placeholder="Entrez votre produit">
                                        </div>
                                        <div class="form-group mt-2">
                                            <div class="card text-start">
                                                <div class="card-body">
                                                    <div class="table-responsive">
                                                        <table class="table table-striped datatable TableProductAchat">
                                                            <thead class="thead-light">
                                                                <tr>
                                                                    <th scope="col">Produit</th>
                                                                    <th scope="col">Quantité</th>
                                                                    <th scope="col">Seuil</th>
                                                                    <th scope="col">Prix Achat</th> 
                                                                    <th scope="col">Local</th> 
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <!-- Les données seront chargées par DataTables -->
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                           </div>
                           <div class="col-sm-12 col-md-12 col-xl-6">
                                <div class="card shadow bg-light">
                                    <div class="card-body">
                                        <div class="form-group mt-3" style="min-height: 123px;">
                                            <div class="card text-start">
                                                <div class="card-body">
                                                    <p class="card-text">Total : <span class="TotalByFournisseurAndUser">0.00</span> </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group mt-3">
                                            <div class="card-body">
                                                <div class="table-responsive">
                                                    <table class="table table-striped datatable TableAmpAchat">
                                                        <thead class="thead-light">
                                                            <tr>
                                                                <th scope="col">Produit</th>
                                                                <th scope="col">Prix Achat</th>
                                                                <th scope="col">Quantité</th>
                                                                <th scope="col">Fournisseur</th>
                                                                <th scope="col">Action</th>    
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <!-- Les données seront chargées par DataTables -->
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            
                                
                           </div>
                        </div>
                    </div>
                    <div class="modal-footer text-end">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                        <button type="button" class="btn btn-primary" id="BtnSaveAchat">Sauvegarder</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

  <div class="modal fade" id="ModalAddProduct" tabindex="-1" aria-labelledby="ModalAddProductLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalAddProductLabel">Ajouter un nouveau produit</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Erreurs de validation -->
                        <ul class="validationAddProduct"></ul>

                        <!-- Formulaire d'ajout de produit -->
                        <form id="FormAddProduct" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <!-- Informations de base du produit -->
                               <div class="row mb-3">
                                <div class="col-md-6">
                                  <div class="form-group">
                                    <label>Classe</label>
                                   <select name="class" id="Class_Categorie" class="form-control" required>
                                   <option value="">Sélectionner une classe</option>
                                   <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->classe); ?>"><?php echo e($item->classe); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </select>
                                 </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Catégorie</label>
                                        <select name="id_categorie" id="id_categorie" class="form-control" required>
                                            <option value="">Sélectionner une catégorie</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Famille</label>
                                        <select name="id_subcategorie" id="id_subcategorie" class="form-control" required>
                                            <option value="">Sélectionner une famille</option>
                                            <!-- Sera rempli dynamiquement -->
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Désignation</label>
                                        <input type="text" name="name" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Unité</label>
                                        <select name="id_unite" id="id_unite" class="form-control" required>
                                            <option value="">Sélectionner une unité</option>
                                            <?php $__currentLoopData = $unites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($unite->id); ?>"><?php echo e($unite->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Catégorie et Sous-catégorie -->
                          

                            <!-- Emplacement -->
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Local</label>
                                        <select name="id_local" id="id_local" class="form-control" required>
                                            <option value="">Sélectionner un local</option>
                                            <?php $__currentLoopData = $locals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($local->id); ?>"><?php echo e($local->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Rayon</label>
                                        <select name="id_rayon" id="id_rayon" class="form-control" required>
                                            <option value="">Sélectionner un rayon</option>
                                            <!-- Sera rempli dynamiquement -->
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <!-- Prix -->
                            <div class="row mb-3">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Prix d'achat</label>
                                    <input type="number" step="0.01" name="price_achat" class="form-control" required>
                                </div>
                            </div>
                        </div>

                        <!-- Stock et Taxe -->
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Quantité</label>
                                    <input type="number" step="0.01" name="quantite" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Seuil</label>
                                    <input type="number" step="0.01" name="seuil" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>TVA</label>
                                    <select name="id_tva" class="form-control" required>
                                        <option value="">Sélectionner une TVA</option>
                                        <?php $__currentLoopData = $tvas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($tva->id); ?>"><?php echo e($tva->value); ?>%</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <!-- Informations supplémentaires -->
                        <div class="row mb-3">
                            <!-- <div class="col-md-4">
                                <div class="form-group">
                                    <label>Code barre</label>
                                    <input type="text" name="code_barre" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Photo</label>
                                    <input type="file" name="photo" id="photo" class="form-control" accept="image/*">
                                </div>
                                <div id="photo_preview" class="mt-2" style="display: none;"></div>
                            </div> -->
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Date d'expiration</label>
                                    <input type="date" name="date_expiration" class="form-control">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                    <button type="button" class="btn btn-primary" id="BtnAddProduct">Sauvegarder</button>
                </div>
            </div>
        </div>
    </div>

        <!-- Modal Modifier un Achat -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Achat-modifier')): ?>
        <div class="modal fade" id="ModalEditAchat" tabindex="-1" aria-labelledby="ModalEditAchatLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="ModalEditAchatLabel">Modifier le statut d'achat</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="validationEditAchat"></div>
                        <div class="mb-3">
                            <label for="status" class="form-label">Statut</label>
                            <select class="form-select"  name="status" id="StatusAchat"> 
                                <option value="0" selected>Veuillez sélectionner le statut</option>
                                

                                
                                <?php if(Auth::user()->getRoleNames()->contains('Magasinier')): ?>
                                    <option value="Livraison">Livraison</option>
                                <?php endif; ?>
                                
                                <?php if(Auth::user()->getRoleNames()->contains('Administrateur')): ?>
                                    <option value="Refus">Refus</option>
                                    <option value="Validation">Validation</option>
                                   
                                <?php endif; ?>
                                
                                <option value="Réception">Réception</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                        <button type="button" class="btn btn-primary" id="BtnChangeStatusAchat">Mettre à jour</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Modal Modifier Quantité -->
  
        <div class="modal fade" id="ModalEditQteTmp" tabindex="-1" role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content" style="background-color: ##dee8f0 !important">
                    <div class="modal-header">
                        <h5 class="modal-title text-uppercase" id="modalTitleId">
                            Modifier quantité
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <ul class="validationUpdateQteTmp"></ul>
                            <label for="">Quantité :</label>
                            <input type="number" min="1" class="form-control" id="QteTmp">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" id="BtnUpdateQteTmp">Sauvegarder</button>
                    </div>
                </div>
            </div>
        </div>
    
        
    </div>
</div>
<script>
    $('#Class_Categorie').on('change',function()
{
    let name = $(this).val();
    
    $.ajax({
        type: "GET",
        url: GetCategorieByClass,
        data: 
        {
            class : name,
        },
        dataType: "json",
        success: function (response) {
            if(response.status == 200)
            {
                let $dropdown =$('#Categorie_Class');
                $dropdown.empty();
                
                $.each(response.data,function(index, item){
                    $dropdown.append('<option value="' +item.id+ '">' + item.name + '</option>');
                });
            }
        }
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/u815974231/domains/red-guanaco-935735.hostingersite.com/public_html/resources/views/achat/index.blade.php ENDPATH**/ ?>