@php
            $totalTTC = 0;
            $totalTVA = 0;
            $productsList = [];
            
            // Combine all products from all consumptions
            if (isset($data['consumptions']) && is_array($data['consumptions']) && !empty($data['consumptions'])) {
                foreach ($data['consumptions'] as $consumption) {
                    if (isset($consumption['products']) && is_array($consumption['products'])) {
                        foreach ($consumption['products'] as $product) {
                            $existingIndex = -1;
                            foreach ($productsList as $index => $existingProduct) {
                                if ($existingProduct['name'] == $product['name']) {
                                    $existingIndex = $index;
                                    break;
                                }
                            }
                            
                            if ($existingIndex >= 0) {
                                $productsList[$existingIndex]['quantity'] += $product['quantity'];
                                $productsList[$existingIndex]['total_price'] += $product['total_price'];
                                if (isset($product['tva_amount'])) {
                                    $productsList[$existingIndex]['tva_amount'] = ($productsList[$existingIndex]['tva_amount'] ?? 0) + $product['tva_amount'];
                                }
                            } else {
                                $productsList[] = $product;
                            }
                        }
                    }
                }
            }
            
            // Calculate totals
            foreach ($productsList as $product) {
                $prixTTC = $product['total_price'] ?? 0;
                $tvaRate = $product['tva_rate'] ?? 0;
                $tvaAmount = (!isset($product['tva_amount']) || $product['tva_amount'] == 0 || $tvaRate == 0) 
                    ? $prixTTC 
                    : $product['tva_amount'];
                
                $totalTVA += $tvaAmount;
                $totalTTC += $prixTTC;
            }
            
            // Sort products by name only (no category sorting)
            if (!empty($productsList)) {
                usort($productsList, function($a, $b) {
                    return ($a['name'] ?? '') <=> ($b['name'] ?? '');
                });
            }
        @endphp<!DOCTYPE html>
<html>
<head>
    <title>Feuille de Consommation</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            font-family: DejaVu Sans !important;
        }
       
        @page {
            size: a4;
            margin: 0;
            padding: 0;
        }
        
        .invoice-box table {
            direction: ltr;
            width: 100%;
            text-align: right;
            border: 1px solid;
            font-family: 'DejaVu Sans', 'Roboto', 'Montserrat', 'Open Sans', sans-serif;
        }
        
        .row, .column {
            display: block;
            page-break-before: avoid;
            page-break-after: avoid;
        }
        
        .page-break {
            page-break-after: always;
        }
        
        .invoice-container {
            height: 1060px;
            position: relative;
            border: 1px solid;
            padding: 15px;
            margin-bottom: 15px;
            background-color: #ffffff; 
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); 
        }
        
        .container {
            width: 98%;
            margin: 15px;
            box-sizing: border-box;
        }
        
        /* Header image adjustments */
        .header-image {
            width: 650px;
            height: auto;
            max-height: 80px;
            object-fit: contain;
            display: block;
            margin: 0 auto;
        }
        
        .header-container {
            text-align: center;
            width: 100%;
        }
        
        #tableDetail {
            width: 100%;
            border-collapse: collapse;
            font-size: 8px;
        }
        
        #tableDetail th,
        #tableDetail td {
            border: 1px solid;
            padding: 3px;
            text-align: left;
            font-size: 7px;
        }
        
        #tableDetail th {
            background-color: #f2f2f2;
            font-weight: bold;
            font-size: 8px;
            white-space: nowrap;
        }
        
        /* Footer adjustments */
        .invoice-footer {
            text-transform: uppercase;
            white-space: nowrap;
            margin-top: 2px;
            bottom: 5px;
            position: absolute;
            width: 100%;
            text-align: center;
        }
        
        .footer-image {
            width: 650px;
            height: auto;
            max-height: 60px;
            object-fit: contain;
            display: block;
            margin: 0 auto;
        }
        
        .title-centered {
            text-align: center;
            font-weight: bold;
            font-size: 14px;
            margin: 10px 0;
        }
        
        .menu-title {
            text-align: center;
            font-weight: normal;
            font-size: 12px;
            margin: 8px 0;
        }
        
        .journee-heading {
            font-weight: bold;
            font-size: 12px;
            margin: 15px 0 8px 0;
        }
        
        /* NEW: Menu attributes styling */
        .menu-attributes-list {
            margin: 8px 0;
            padding-left: 0;
            list-style: none;
        }
        
        .menu-attributes-list li {
            margin: 3px 0;
            font-size: 12px;
            font-weight: normal;
        }
        
        .menu-content {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
        }
        
        .menu-items-container {
            width: 60%;
            float: left;
        }
        
        .effectifs-container {
            width: 40%;
            float: right;
        }
        
        .menu-items {
            list-style-type: none;
            padding-left: 0;
        }
        
        .menu-items li {
            margin: 4px 0;
            text-align: left;
        }
        
        .effectifs-title {
            font-weight: bold;
            margin-bottom: 8px;
            text-align: left;
            font-size: 11px;
        }
        
        .effectifs-table {
            width: auto;
            margin-left: auto;
            border-collapse: collapse;
            font-size: 10px;
        }
        
        .effectifs-table td {
            padding: 2px 8px;
            text-align: right;
        }
        
        .effectifs-table td:first-child {
            text-align: left;
        }
        
        .price-summary {
            margin-top: 15px;
            font-weight: bold;
            font-size: 11px;
        }
        
        .price-summary p {
            margin: 4px 0;
        }
        
        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }
    </style>
</head>
<body>
    @php
        // Calculate how many pages we need based on items per page
        $itemsPerPage = 12;
        $totalItems = count($productsList);
        $totalPages = max(1, ceil($totalItems / $itemsPerPage)); // Ensure at least 1 page
        
        // Get other data once
        $type_commande = isset($data['type_commande']) ? $data['type_commande'] : '';
        $displayMenuType = '';
        $menuType = '';
        $totalEleves = 0;
        $totalPersonnel = 0;
        $totalInvites = 0;
        $totalDivers = 0;
        $grandTotal = 0;
        
        // NEW: Get menu attributes
        $menuAttributes = [];
        
        if (isset($data['consumptions']) && is_array($data['consumptions']) && !empty($data['consumptions'])) {
            foreach ($data['consumptions'] as $consumption) {
                if (isset($consumption['type_menu']) && !empty($consumption['type_menu'])) {
                    $displayMenuType = $consumption['type_menu'];
                    $menuType = $consumption['type_menu'];
                }
                
                // Collect menu attributes - they should be available from your controller's getFilteredConsumptionData method
                if (isset($consumption['entree']) && !empty($consumption['entree'])) {
                    $menuAttributes['entree'] = $consumption['entree'];
                }
                if (isset($consumption['plat_principal']) && !empty($consumption['plat_principal'])) {
                    $menuAttributes['plat_principal'] = $consumption['plat_principal'];
                }
                if (isset($consumption['accompagnement']) && !empty($consumption['accompagnement'])) {
                    $menuAttributes['accompagnement'] = $consumption['accompagnement'];
                }
                if (isset($consumption['dessert']) && !empty($consumption['dessert'])) {
                    $menuAttributes['dessert'] = $consumption['dessert'];
                }
                
                if (isset($consumption['eleves'])) {
                    $totalEleves += $consumption['eleves'];
                }
                if (isset($consumption['personnel'])) {
                    $totalPersonnel += $consumption['personnel'];
                }
                if (isset($consumption['invites'])) {
                    $totalInvites += $consumption['invites'];
                }
                if (isset($consumption['divers'])) {
                    $totalDivers += $consumption['divers'];
                }
            }
            $grandTotal = $totalEleves + $totalPersonnel + $totalInvites + $totalDivers;
        }
        
        // Calculate summary data once
        $totalCost = isset($data['grand_totals']['total_cost']) ? $data['grand_totals']['total_cost'] : $totalTTC;
        $averagePrice = 0;
        
        if (isset($data['consumptions']) && is_array($data['consumptions']) && !empty($data['consumptions'])) {
            $averagePrice = isset($data['consumptions'][0]['average_cost_per_person']) ? $data['consumptions'][0]['average_cost_per_person'] : 0;
        }
        
        if ($grandTotal > 0 && $averagePrice == 0) {
            $averagePrice = $totalCost / $grandTotal;
        }
    @endphp

    @for ($page = 0; $page < $totalPages; $page++)
        <div class="invoice-container">
            <!-- Header Image -->
            <div class="header-container">
                <img src="data:image/png;base64,{{ $imageData ?? '' }}" alt="" class="header-image">
            </div>
            
            <!-- Title -->
            <div class="container">
                <div style="display: flex;justify-content: center;text-align: center;width: 100%;">
                    <h3 class="title-centered">Feuille de Consommation (Reporting)</h3>
                </div>
                
                @if($type_commande == 'Alimentaire')
                    <div style="display: flex;justify-content: center;text-align: center;width: 100%;">
                        <p class="menu-title">{{ $displayMenuType }}</p>
                    </div>
                @endif
            </div>
            
            <!-- Main Content -->
            <div class="container">
                <!-- Date and Menu Items (only on first page) -->
                @if($page == 0)
                    <p class="journee-heading">➤ Journée du : {{ $date ?? '' }}</p>
                    
                    {{-- NEW: Add menu attributes and effectifs side by side --}}
                    @if (!empty($menuAttributes) || ($type_commande == 'Alimentaire' && isset($data['consumptions']) && is_array($data['consumptions']) && !empty($data['consumptions'])))
                        <div class="menu-content clearfix">
                            <div class="menu-items-container">
                                @if (!empty($menuAttributes))
                                    <ul class="menu-attributes-list">
                                        @if (isset($menuAttributes['entree']))
                                            <li>• : {{ $menuAttributes['entree'] }}</li>
                                        @endif
                                        @if (isset($menuAttributes['plat_principal']))
                                            <li>• : {{ $menuAttributes['plat_principal'] }}</li>
                                        @endif
                                        @if (isset($menuAttributes['accompagnement']))
                                            <li>• : {{ $menuAttributes['accompagnement'] }}</li>
                                        @endif
                                        @if (isset($menuAttributes['dessert']))
                                            <li>• : {{ $menuAttributes['dessert'] }}</li>
                                        @endif
                                    </ul>
                                @endif
                            </div>
                            
                            @if ($type_commande == 'Alimentaire' && isset($data['consumptions']) && is_array($data['consumptions']) && !empty($data['consumptions']))
                                <div class="effectifs-container">
                                    <p class="effectifs-title">Effectifs :</p>
                                    <table class="effectifs-table">
                                        <tr>
                                            <td>Élèves Stagiaires</td>
                                            <td>: {{ $totalEleves }}</td>
                                        </tr>
                                        <tr>
                                            <td>Personnel en Service</td>
                                            <td>: {{ $totalPersonnel }}</td>
                                        </tr>
                                        <tr>
                                            <td>Invités</td>
                                            <td>: {{ $totalInvites }}</td>
                                        </tr>
                                        <tr>
                                            <td>Divers</td>
                                            <td>: {{ $totalDivers }}</td>
                                        </tr>
                                        <tr>
                                            <td><strong>Total</strong></td>
                                            <td><strong>: {{ $grandTotal }}</strong></td>
                                        </tr>
                                    </table>
                                </div>
                            @endif
                        </div>
                    @endif
                @endif
                
                <!-- Products Table -->
                <table id="tableDetail" style="margin-top: 15px;">
                    <thead>
                        <tr>
                            <th>Désignations des Prestations</th>
                            <th>Unité de Mesure</th>
                            <th>Qté</th>
                            <th>Prix Unitaire HT</th>
                            <th>Taux TVA</th>
                            <th>TOTAL TVA</th>
                            <th>Prix Total TTC</th>
                        </tr>
                    </thead>
                    <tbody>
                        @php
                            // Calculate start and end indices for this page
                            $startIndex = $page * $itemsPerPage;
                            $endIndex = min(($page + 1) * $itemsPerPage, $totalItems);
                        @endphp

                        @if($totalItems > 0)
                            @for ($i = $startIndex; $i < $endIndex; $i++)
                                @php
                                    $product = $productsList[$i];
                                    $tvaRate = $product['tva_rate'] ?? 0;
                                    $tvaLabel = $tvaRate > 0 ? $tvaRate . '%' : 'Pas de TVA';
                                    $prixHT = $product['unit_price'] ?? 0;
                                    $prixTTC = $product['total_price'] ?? 0;
                                    $tvaAmount = (!isset($product['tva_amount']) || $product['tva_amount'] == 0 || $tvaRate == 0) 
                                        ? $prixTTC 
                                        : $product['tva_amount'];
                                    $unite = $product['unite_mesure'] ?? 'kg';
                                @endphp
                                
                                <tr>
                                    <td>{{ $product['name'] ?? '' }}</td>
                                    <td>{{ $unite }}</td>
                                    <td>{{ sprintf("%02d", $product['quantity'] ?? 0) }}</td>
                                    <td>{{ number_format($prixHT, 2) }}</td>
                                    <td>{{ $tvaLabel }}</td>
                                    <td>{{ number_format($tvaAmount, 2) }}</td>
                                    <td>{{ number_format($prixTTC, 2) }}</td>
                                </tr>
                            @endfor
                            
                            <!-- Add empty rows to maintain consistent page height -->
                            @for ($i = $endIndex - $startIndex; $i < $itemsPerPage; $i++)
                                <tr>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                </tr>
                            @endfor
                        @else
                            <!-- Empty products case -->
                            <tr>
                                <td colspan="7" style="text-align: center;">Aucun produit trouvé</td>
                            </tr>
                            
                            <!-- Add empty rows to maintain consistent page height -->
                            @for ($i = 1; $i < $itemsPerPage; $i++)
                                <tr>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                    <td>&nbsp;</td>
                                </tr>
                            @endfor
                        @endif
                        
                        <!-- Total row on last page -->
                        @if ($page == $totalPages - 1)
                            <tr>
                                <td colspan="6" style="text-align: right;"><strong>TOTAL TTC</strong></td>
                                <td><strong>{{ number_format($totalTTC, 2) }}</strong></td>
                            </tr>
                        @endif
                    </tbody>
                </table>
                
                <!-- Price Summary (only on last page) -->
                @if ($page == $totalPages - 1)
                    <div class="price-summary" style="margin-top: 15px;">
                        <p>➤ Prix de Revient de La Journée : {{ number_format($totalCost, 2) }}</p>
                        
                        @if ($type_commande == 'Alimentaire' && $menuType)
                            <p>➤ Prix Moyen {{ $menuType }} : {{ number_format($averagePrice, 2) }}</p>
                        @endif
                        
                        <p>➤ Prix Moyen Général : {{ number_format($averagePrice, 2) }}</p>
                    </div>
                @endif
            </div>
            
            <!-- Footer -->
            <footer>
                <div class="invoice-footer">
                    <img src="data:image/png;base64,{{ $imageData_bottom ?? '' }}" alt="" class="footer-image">
                </div>
            </footer>
        </div>

        @if ($page < $totalPages - 1)
            <div class="page-break"></div>
        @endif
    @endfor
</body>
</html>